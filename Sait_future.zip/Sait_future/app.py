from flask import Flask, request, jsonify, render_template
from openai import OpenAI
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import requests

app = Flask(__name__)

def generate_text(prompt):
    try:
        # Создание клиента для подключения к OpenAI
        client = OpenAI(api_key='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')
        # Генерация текста с использованием OpenAI API
        response = client.chat.completions.create(
            timeout=60,
            model="ft:gpt-3.5-turbo-1106:t1::8mJFSyqI",
            messages=[
                {"role": "system",
                 "content": "IDN является чат-ботом, который помогает предсказывать значение BTC с использованием текущей даты; open, high, low и close - это термины, используемые в торговле акциями для обозначения цен, с которых акция начала торговаться, достигла своих максимальных и минимальных точек и закончила торговаться в заданный период времени, соответственно."},
                {"role": "user", "content": prompt}
            ],
        )
        # Возврат последнего числа из сгенерированного сообщения
        return float(response.choices[0].message.content.split()[-1])
    except Exception as e:
        # Возврат ошибки, если что-то пошло не так
        return str(e)


# URL API Binance для получения текущей цены BTC
binance_api_url = 'https://api.biвыаnance.com/api/v3/ticker/price?symbol=BTCUSDT'

def get_btc_price():
    try:
        # Запрос к API Binance для получения текущей цены BTC
        response = requests.get(binance_api_url)
        if response.status_code == 200:
            data = response.json()
            # Возврат текущей цены BTC
            return float(data['price'])
        else:
            # Возврат None, если статус ответа не 200
            return None
    except Exception as e:
        # Возврат ошибки, если что-то пошло не так
        return str(e)


@app.route('/')
def index():
    # Отображение начальной страницы
    return render_template('indexf.html')


@app.route('/predict', methods=['POST'])
def predict():
    # Получение данных от пользователя через POST запрос
    data = request.get_json()
    user_input = data['text']
    # Генерация ответа модели
    model_response = generate_text(user_input)
    response = {
        "prediction": model_response
    }
    # Возврат ответа в формате JSON
    return jsonify(response)

database = 'user_data.db'

def get_db_connection():
    conn = sqlite3.connect(database)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with app.app_context():
        db = get_db_connection()
        db.execute('''CREATE TABLE IF NOT EXISTS users (
                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                      username TEXT NOT NULL UNIQUE,
                      password TEXT NOT NULL,
                      email TEXT NOT NULL UNIQUE)''')
        db.commit()

@app.before_first_request
def initialize():
    init_db()

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data['username']
    password = data['password']
    email = data['email']

    db = get_db_connection()
    user_by_username = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    user_by_email = db.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()

    if user_by_username:
        return jsonify({"message": "This username is already taken."}), 400

    if user_by_email:
        return jsonify({"message": "This email is already registered."}), 400

    password_hash = generate_password_hash(password)

    db.execute('INSERT INTO users (username, password, email) VALUES (?, ?, ?)', (username, password_hash, email))
    db.commit()

    return jsonify({"message": "User registered successfully!"}), 201


@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data['username']
    password = data['password']
    
    db = get_db_connection()
    user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    
    if user and check_password_hash(user['password'], password):
        return jsonify({"success": True}), 200
    else:
        return jsonify({"success": False}), 401

if __name__ == '__main__':
    # Запуск сервера Flask в режиме отладки
    app.run(debug=True)
